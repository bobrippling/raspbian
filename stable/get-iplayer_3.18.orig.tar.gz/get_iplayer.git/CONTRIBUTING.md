See: <https://github.com/get-iplayer/get_iplayer/wiki/contribute>
