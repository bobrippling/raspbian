#!/bin/bash

RELEASES="${RELEASES:-trusty xenial zesty artful bionic}"
mydir=$(dirname $(readlink -f $0))
parentdir=$(dirname $(readlink -f $mydir))

$mydir/make-get-git-repo.sh

# get a clean version of the git repository
cd $parentdir
rm -rf get_iplayer.git
tar xf get_iplayer.git.tar

# copy the debian directory into place and adjust
cp -R $mydir $parentdir/get_iplayer.git
cd $mydir
# get a version number for this release
cat versionppa.sh | sed s/verppa=.*$/verppa=$(git describe --tags | sed 's/-/x/g')/ > $parentdir/get_iplayer.git/debian/versionppa.sh
cd $parentdir/get_iplayer.git/debian/
$parentdir/get_iplayer.git/debian/make-version-patch.sh

# make an orig.tar.gz
$parentdir/get_iplayer.git/debian/make-orig.tar.gz.sh

# build source debs for each release
for dist in $RELEASES; do
  cd $parentdir/get_iplayer.git
  # only the debian changelog changes per dist, update it with a fudge
  # try and fetch the last built changelog from /usr/share/doc/get-iplayer/changelog.Debian.gz
  test -f /usr/share/doc/get-iplayer/changelog.Debian.gz && zcat /usr/share/doc/get-iplayer/changelog.Debian.gz > $mydir/changelog
  cp $mydir/changelog debian/changelog
  LASTTAGVER=v$(head -1 debian/changelog | cut -f2 -d\( | cut -f1 -d-)
  LASTTAG=$(git rev-parse $LASTTAGVER)
  dch -b -v $($parentdir/get_iplayer.git/debian/versionppa.sh)~$dist -D $dist "New upstream snapshot"
  # and add the short git logs
  git log $LASTTAG.. --pretty=format:"%h: %s [%an]" | while read -r ll ; do dch -a "$ll" ; done
  # and build the source packages
  if [ -z $DEBSIGN_KEYID ]; then
    debuild -S -sa
  else
    debuild -S -sa -k$DEBSIGN_KEYID
  fi
done

