#!/bin/bash

debiandir=$(dirname $(readlink -f $0))

verppa=ppa31c

echo $($debiandir/version.sh)-$verppa
