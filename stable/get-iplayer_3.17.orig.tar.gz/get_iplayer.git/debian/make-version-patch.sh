#!/bin/bash

debiandir=$(dirname $(readlink -f $0))
packagedir=$(dirname $debiandir)
PATCHFILE=$debiandir/patches/001-debian-package-version.patch
VERSION=$($debiandir/versionppa.sh)
GETIPLAYER=$packagedir/get_iplayer
SERIES=$debiandir/patches/series

# we're going to update a line like "my $version_text;"

echo --- a/get_iplayer > $PATCHFILE
echo +++ b/get_iplayer >> $PATCHFILE

LINENUM=$(grep -n "^my \$version_text" $GETIPLAYER | cut -f1 -d:)
VERSTEXT=$(grep -n "^my \$version_text" $GETIPLAYER | cut -f2 -d:)
LINEFROM=$(($LINENUM - 3))
echo @@ -$LINEFROM,7 +$LINEFROM,7 @@ >> $PATCHFILE
grep --context=3 "^$VERSTEXT" $GETIPLAYER | sed "s/^\(.*\)$/ \1/;s/^ $VERSTEXT/-$VERSTEXT\n+my \$version_text = '$VERSION'\;/" >> $PATCHFILE

PATCHFILE=$debiandir/patches/002-debian-package-version.patch
GETIPLAYERCGI=$packagedir/get_iplayer.cgi

# we're going to update a line like "my $VERSION_TEXT;"

echo --- a/get_iplayer.cgi > $PATCHFILE
echo +++ b/get_iplayer.cgi >> $PATCHFILE

LINENUM=$(grep -n "^my \$VERSION_TEXT" $GETIPLAYERCGI | cut -f1 -d:)
VERSTEXT=$(grep -n "^my \$VERSION_TEXT" $GETIPLAYERCGI | cut -f2 -d:)
LINEFROM=$(($LINENUM - 3))
echo @@ -$LINEFROM,7 +$LINEFROM,7 @@ >> $PATCHFILE
grep --context=3 "^$VERSTEXT" $GETIPLAYERCGI | sed "s/^\(.*\)$/ \1/;s/^ $VERSTEXT/-$VERSTEXT\n+my \$VERSION_TEXT = '$VERSION'\;/" >> $PATCHFILE

# add these two patches in the series file
echo 001-debian-package-version.patch >> $SERIES
echo 002-debian-package-version.patch >> $SERIES

