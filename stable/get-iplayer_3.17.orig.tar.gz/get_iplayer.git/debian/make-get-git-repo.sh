#!/bin/bash

GITREPO=git@github.com:get-iplayer/get_iplayer.git
# define GITBRANCH to build any other branch, such as develop
GITBRANCH="${GITBRANCH:-master}"

mydir=$(dirname $(readlink -f $0))
parentdir=$(dirname $(readlink -f $mydir))

#get a clean and up to date version of the git repository
cd $parentdir
rm -rf get_iplayer.git
if [ -f get_iplayer.git.tar ]; then
  # update an existing copy of the repo
  tar xf get_iplayer.git.tar
  cd get_iplayer.git
  git pull
  cd ..
  rm -f get_iplayer.git.tar
  tar cf get_iplayer.git.tar get_iplayer.git
else
  # get a fresh copy of the repo
  git clone -b $GITBRANCH $GITREPO get_iplayer.git
  tar cf get_iplayer.git.tar get_iplayer.git
fi
