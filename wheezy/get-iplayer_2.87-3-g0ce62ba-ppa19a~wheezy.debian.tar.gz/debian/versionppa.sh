#!/bin/bash

debiandir=$(dirname $(readlink -f $0))

verppa=ppa19a

echo $($debiandir/version.sh)-$verppa
