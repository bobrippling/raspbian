#!/bin/bash

#GITREPO=git://git.infradead.org/get_iplayer
GITREPO=git@github.com:dinkypumpkin/get_iplayer.git

mydir=$(dirname $(readlink -f $0))
parentdir=$(dirname $(readlink -f $mydir))

#get a clean and up to date version of the git repository
cd $parentdir
rm -rf get_iplayer.git
if [ -f get_iplayer.git.tar ]; then
  tar xf get_iplayer.git.tar
  cd get_iplayer.git
  git pull
  cd ..
  rm -f get_iplayer.git.tar
  tar cf get_iplayer.git.tar get_iplayer.git
else
  git clone $GITREPO get_iplayer.git
  tar cf get_iplayer.git.tar get_iplayer.git
fi
