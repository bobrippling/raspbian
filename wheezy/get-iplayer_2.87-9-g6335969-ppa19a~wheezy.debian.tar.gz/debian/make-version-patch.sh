#!/bin/bash

debiandir=$(dirname $(readlink -f $0))
packagedir=$(dirname $debiandir)
PATCHFILE=$debiandir/patches/001-debian-package-version.patch
VERSION=$($debiandir/versionppa.sh)
GETIPLAYER=$packagedir/get_iplayer
SERIES=$debiandir/patches/series

# we're going to update a line like "my $version_text;"

echo --- a/get_iplayer > $PATCHFILE
echo +++ b/get_iplayer >> $PATCHFILE

LINENUM=$(grep -n "^my \$version_text;" $GETIPLAYER | cut -f1 -d:)
LINEFROM=$(($LINENUM - 3))
echo @@ -$LINEFROM,7 +$LINEFROM,7 @@ >> $PATCHFILE
grep --context=3 "^my \$version_text;" $GETIPLAYER | sed "s/^\(.*\)$/ \1/;s/^ my \$version_text\;/-my \$version_text\;\n+my \$version_text = '$VERSION'\;/" >> $PATCHFILE

PATCHFILE=$debiandir/patches/002-debian-package-version.patch
GETIPLAYERCGI=$packagedir/get_iplayer.cgi

# we're going to update a line like "my $VERSION_TEXT;"

echo --- a/get_iplayer.cgi > $PATCHFILE
echo +++ b/get_iplayer.cgi >> $PATCHFILE

LINENUM=$(grep -n "^my \$VERSION_TEXT;" $GETIPLAYERCGI | cut -f1 -d:)
LINEFROM=$(($LINENUM - 3))
echo @@ -$LINEFROM,7 +$LINEFROM,7 @@ >> $PATCHFILE
grep --context=3 "^my \$VERSION_TEXT;" $GETIPLAYERCGI | sed "s/^\(.*\)$/ \1/;s/^ my \$VERSION_TEXT\;/-my \$VERSION_TEXT\;\n+my \$VERSION_TEXT = '$VERSION'\;/" >> $PATCHFILE

# add these two patches in the series file
echo 001-debian-package-version.patch >> $SERIES
echo 002-debian-package-version.patch >> $SERIES

