#!/bin/bash

mydir=$(dirname $(readlink -f $0))
parentdir=$(dirname $(readlink -f $mydir))

$mydir/make-get-git-repo.sh

# get a clean version of the git repository
cd $parentdir
rm -rf get_iplayer.git
tar xf get_iplayer.git.tar

# copy the debian directory into place and adjust
cp -R $mydir $parentdir/get_iplayer.git
cd $mydir
# get a version number for this release
cat versionppa.sh | sed s/verppa=.*$/verppa=$(git describe --tags | sed 's/-/x/g')/ > $parentdir/get_iplayer.git/debian/versionppa.sh
cd $parentdir/get_iplayer.git/debian/
$parentdir/get_iplayer.git/debian/make-version-patch.sh
# record the actual git log
cd $parentdir/get_iplayer.git
git log > $parentdir/get_iplayer.git/debian/README.git-log

# make an orig.tar.gz
$parentdir/get_iplayer.git/debian/make-orig.tar.gz.sh

# build debs for each release
for dist in wheezy ; do
  cd $parentdir/get_iplayer.git
  # only the debian changelog changes per dist, update it with a fudge
  cp $mydir/changelog debian/changelog
  dch --force-distribution -v $($parentdir/get_iplayer.git/debian/versionppa.sh)~$dist -D $dist "New upstream snapshot, see README.git-log"
  # and build full soruce and binary packages
  dpkg-buildpackage -sa
done

