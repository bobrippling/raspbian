#!/bin/bash

debiandir=$(dirname $(readlink -f $0))

verppa=ppa20p1

echo $($debiandir/version.sh)-$verppa
