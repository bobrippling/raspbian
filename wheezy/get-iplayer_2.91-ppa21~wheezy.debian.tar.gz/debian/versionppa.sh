#!/bin/bash

debiandir=$(dirname $(readlink -f $0))

verppa=ppa21

echo $($debiandir/version.sh)-$verppa
