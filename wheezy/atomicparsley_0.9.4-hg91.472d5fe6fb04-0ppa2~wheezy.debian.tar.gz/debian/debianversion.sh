#!/bin/bash
debiandir=$(dirname $(readlink -f $0))
ppaversion=0ppa2
debianversion=$($debiandir/upstreamversion.sh)-$ppaversion

cat > $debiandir/patches/configure-ac-version.patch <<PATCHEOF
diff -r 814077d09d34 configure.ac
--- a/configure.ac      Sun May 22 11:44:35 2011 +0100
+++ b/configure.ac      Thu Jun 16 12:26:57 2011 +0100
@@ -5,7 +5,7 @@

 AC_PREREQ(2.50)

-AC_INIT([atomicparsley],[0.9.4],
+AC_INIT([atomicparsley],[$debianversion],
   [http://bitbucket.org/wez/atomicparsley/issues/new/])

 dnl Need to disable dependency tracking option so that the universal
PATCHEOF
cd $debiandir/..
dch -v $debianversion "New upstream version"
echo Generated patch and changelog entry for $debianversion
echo Run dch -e to edit the changelog entry

