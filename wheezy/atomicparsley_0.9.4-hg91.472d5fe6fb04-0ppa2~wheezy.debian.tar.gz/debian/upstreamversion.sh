#!/bin/bash
debiandir=$(dirname $(readlink -f $0))
cd $debiandir/..
echo $(hg tags | tail -n +2 | head -1 | cut -f1 -d\ )-hg$(hg summary | grep parent: | cut -f2 -d\  | sed s/:/./g)

