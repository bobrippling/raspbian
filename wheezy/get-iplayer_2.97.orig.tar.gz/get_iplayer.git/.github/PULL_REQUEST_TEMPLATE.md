Ensure that you have read the project contributor guidelines before submitting a pull request:

https://github.com/get-iplayer/get_iplayer/wiki/contribute

Remove these instructions before submitting your pull request.
