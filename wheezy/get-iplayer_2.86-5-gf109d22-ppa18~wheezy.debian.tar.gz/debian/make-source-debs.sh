#!/bin/bash

mydir=$(dirname $(readlink -f $0))
parentdir=$(dirname $(readlink -f $mydir))

#get a clean and up to date version of the git repository
cd $parentdir
rm -rf get_iplayer.git
if [ -f get_iplayer.git.tar ]; then
  tar xf get_iplayer.git.tar
  cd get_iplayer.git
  git pull
  cd ..
  rm -f get_iplayer.git.tar
  tar cf get_iplayer.git.tar get_iplayer.git
else
  git clone git://git.infradead.org/get_iplayer get_iplayer.git
  tar cf get_iplayer.git.tar get_iplayer.git
fi

# do lucid build
# get a clean version of the git repository
cd $parentdir
rm -rf get_iplayer.git
tar xf get_iplayer.git.tar
# copy the debian directory into place and adjust
cp -R $mydir $parentdir/get_iplayer.git
cd $mydir
cat versionppa.sh | sed s/verppa=.*$/verppa=$(git describe --tags | sed 's/-/x/g')/ > $parentdir/get_iplayer.git/debian/versionppa.sh
cd $parentdir/get_iplayer.git/debian/
for f in *.lucid ; do
  cp $f $(basename $f .lucid)
done
$parentdir/get_iplayer.git/debian/make-version-patch.sh
cd $parentdir/get_iplayer.git
git log > $parentdir/get_iplayer.git/debian/README.git-log

# make an orig.tar.gz
$parentdir/get_iplayer.git/debian/make-orig.tar.gz.sh

# do lucid build
for dist in lucid ; do
  cd $parentdir/get_iplayer.git
  # only the debian changelog changes per dist, update it
  cp $mydir/changelog debian/changelog
  dch -v $($parentdir/get_iplayer.git/debian/versionppa.sh)~$dist -D $dist "New upstream snapshot, see README.git-log"
  # and build the source packages
  debuild -S
done

# do precise-onwards builds
# only the .precise files change
cd $parentdir/get_iplayer.git/debian/
for f in *.precise ; do
  cp $f $(basename $f .precise)
done

for dist in precise trusty utopic ; do
  cd $parentdir/get_iplayer.git
  # only the debian changelog changes per dist, update it
  cp $mydir/changelog debian/changelog
  dch -v $($parentdir/get_iplayer.git/debian/versionppa.sh)~$dist -D $dist "New upstream snapshot, see README.git-log"
  # and build the source packages
  debuild -S
done


