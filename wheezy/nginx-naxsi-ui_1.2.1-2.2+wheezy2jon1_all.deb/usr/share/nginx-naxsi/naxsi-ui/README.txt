
nx_intercept.py and nx_extract.py are new naxsi's learning daemons.


nx_intercept.py should be pointed by your /RequestDenied.
nx_extract.py should be launched after nx_intercept.py, and accessed with 
	      a browser (ie: lynx) to obtain generated whitelists.

